package com.surveypacakage.YoutubersSurvey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoutubersSurveyApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoutubersSurveyApplication.class, args);
	}

}
