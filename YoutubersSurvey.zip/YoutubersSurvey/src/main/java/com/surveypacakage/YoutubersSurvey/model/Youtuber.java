package com.surveypacakage.YoutubersSurvey.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Youtuber {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int yid;
	@Column
	private String yname;
	@Column
	private String ydob;
	@Column
	private String contenttag;
	@Column
	private String subcount;
	@Column
	private int yjoinyear;
	
	public Youtuber() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Youtuber(int yid, String yname, String ydob, String contenttag, String subcount, int yjoinyear) {
		
		super();
		this.yid = yid;
		this.yname = yname;
		this.ydob = ydob;
		this.contenttag = contenttag;
		this.subcount = subcount;
		this.yjoinyear = yjoinyear;
	}
	public int getYid() {
		return yid;
	}
	public void setYid(int yid) {
		this.yid = yid;
	}
	public String getYname() {
		return yname;
	}
	public void setYname(String yname) {
		this.yname = yname;
	}
	public String getYdob() {
		return ydob;
	}
	public void setYdob(String ydob) {
		this.ydob = ydob;
	}
	public String getContenttag() {
		return contenttag;
	}
	public void setContenttag(String contenttag) {
		this.contenttag = contenttag;
	}
	public String getSubcount() {
		return subcount;
	}
	public void setSubcount(String subcount) {
		this.subcount = subcount;
	}
	public int getYjoinyear() {
		return yjoinyear;
	}
	public void setYjoinyear(int yjoinyear) {
		this.yjoinyear = yjoinyear;
	}
	@Override
	public String toString() {
		return "Youtuber [yid=" + yid + ", yname=" + yname + ", ydob=" + ydob + ", contenttag=" + contenttag
				+ ", subcount=" + subcount + ", yjoinyear=" + yjoinyear + "]";
	}
	
	
	

}
