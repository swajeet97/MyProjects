package com.surveypacakage.YoutubersSurvey.JpaRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.surveypacakage.YoutubersSurvey.model.Youtuber;

@Repository
@Component
public interface YoutuberRepository extends JpaRepository<Youtuber, Integer> {

	List<Youtuber> findAll();

}
