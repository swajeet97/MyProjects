package com.surveypacakage.YoutubersSurvey.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.surveypacakage.YoutubersSurvey.JpaRepository.YoutuberRepository;
import com.surveypacakage.YoutubersSurvey.model.Youtuber;

@RestController
public class YoutubeersAPIService {
	
	@Autowired
	YoutuberRepository repository;
	
	@RequestMapping("/getYoutubers")
	public List<Youtuber> fetchallYoutubers(){
		
		List<Youtuber> youtubers = repository.findAll();
		return youtubers;
		
	}
	
	@PostMapping("/addnewyou")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void addyoutuber(@RequestBody Youtuber youtuber) {
		 
		repository.save(youtuber);
		
		System.out.println("New Youtuber Information Is Added Successfully..");
		
	}
	
	@PutMapping("/modifyyoutuber/{yid}")
	public Youtuber updateinfo(@PathVariable int yid) {
		
		Youtuber youtuber = repository.findById(yid).get();
		youtuber.setYname("ashish chanchlani vine(Ashish Chanchlani)");
		repository.save(youtuber);
		return youtuber;
		
	}
	
	@DeleteMapping("/removeyoutuber/{yid}")
	public void removeYoutuber(@PathVariable int yid) {
		
		Youtuber youtuber = repository.findById(yid).get();
		repository.delete(youtuber);
		
	}
	
	@GetMapping("/fetchyoutuber/{yid}") 
	public Youtuber fetchbyid(@PathVariable int yid) {
		Youtuber youtuber = repository.findById(yid).get();
		return youtuber;
	
	}
	
	
	
	
	

}
