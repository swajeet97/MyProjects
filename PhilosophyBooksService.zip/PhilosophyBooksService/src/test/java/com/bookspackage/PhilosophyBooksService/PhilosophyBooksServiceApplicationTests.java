package com.bookspackage.PhilosophyBooksService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhilosophyBooksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
