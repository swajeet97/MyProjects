package com.bookspackage.PhilosophyBooksService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhilosophyBooksServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhilosophyBooksServiceApplication.class, args);
	}

}
