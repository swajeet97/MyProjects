package com.bookspackage.PhilosophyBooksService.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Book {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookid;
	private String bookname;
	private String bookauthor;
	private String bookpublishdate;
	private String booklang;
	
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Book(int bookid, String booknmae, String bookauthor, String bookpublishdate, String booklang) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.bookauthor = bookauthor;
		this.bookpublishdate = bookpublishdate;
		this.booklang = booklang;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String booknmae) {
		this.bookname = bookname;
	}
	public String getBookauthor() {
		return bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}
	public String getBookpublishdate() {
		return bookpublishdate;
	}
	public void setBookpublishdate(String bookpublishdate) {
		this.bookpublishdate = bookpublishdate;
	}
	public String getBooklang() {
		return booklang;
	}
	public void setBooklang(String booklang) {
		this.booklang = booklang;
	}
	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", bookname=" + bookname + ", bookauthor=" + bookauthor + ", bookpublishdate="
				+ bookpublishdate + ", booklang=" + booklang + "]";
	}
	
	
	

}
