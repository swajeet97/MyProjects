package com.proectpackage.PnuematicProductsInformationService.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class PneBrands {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int pnebid;
	public String pnebname;
	public String pnebfounder;
	public int pnebfoundyear;
	public String pnebtype;
	
	public PneBrands() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getPnebid() {
		return pnebid;
	}
	public void setPnebid(int pnebid) {
		this.pnebid = pnebid;
	}
	public String getPnebname() {
		return pnebname;
	}
	public void setPnebname(String pnebname) {
		this.pnebname = pnebname;
	}
	public String getPnebfounder() {
		return pnebfounder;
	}
	public void setPnebfounder(String pnebfounder) {
		this.pnebfounder = pnebfounder;
	}
	public int getPnebfoundyear() {
		return pnebfoundyear;
	}
	public void setPnebfoundyear(int pnebfoundyear) {
		this.pnebfoundyear = pnebfoundyear;
	}
	public String getPnebtype() {
		return pnebtype;
	}
	public void setPnebtype(String pnebtype) {
		this.pnebtype = pnebtype;
	}
	@Override
	public String toString() {
		return "PneBrands [pnebid=" + pnebid + ", pnebname=" + pnebname + ", pnebfounder=" + pnebfounder
				+ ", pnebfoundyear=" + pnebfoundyear + ", pnebtype=" + pnebtype + "]";
	}
	
	
	
	
	

}
