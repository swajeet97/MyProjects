package com.proectpackage.PnuematicProductsInformationService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.proectpackage.PnuematicProductsInformationService.Model.PneBrands;
import com.proectpackage.PnuematicProductsInformationService.Repository.PneBrandRepository;

@RestController
public class PneBrandsAPIService {
	
	@Autowired
	PneBrandRepository pnebrandRepository;
	
	@RequestMapping("pneblist")
	public List<PneBrands> fetchallPneBrands(){
		
		List <PneBrands> pbrands = pnebrandRepository.findAll();
		
		return pbrands;
	}
	
	@PostMapping("newpnebrand")
	@ResponseStatus(code=HttpStatus.CREATED)
	public void addProduct (@RequestBody PneBrands pneBrands) {
		
		pnebrandRepository.save(pneBrands);
		System.out.println("Brand Added Successfully");
		
		
	}
	
	@PutMapping("modifybrand/{pnebid}")
	public PneBrands updatepnebrand(@PathVariable int pnebid) {
		
		PneBrands pneBrands = pnebrandRepository.findById(pnebid).get();
		pneBrands.setPnebtype("Design and Manufacturing");
		
		return pneBrands;
		
		
	}
	
	@DeleteMapping("deletebrand/{pnebid}")
	public void removetheProduct(@PathVariable int pnebid) {
		
	 PneBrands pneBrands = pnebrandRepository.findById(pnebid).get();
	 pnebrandRepository.delete(pneBrands);
		
	}
	
	@GetMapping("findbyid/{pnebid}")
	 public PneBrands getpnebrandbyid(@PathVariable int pnebid) {
		
     PneBrands pneBrands = pnebrandRepository.findById(pnebid).get();
		
	 return pneBrands;
		
	}

}
