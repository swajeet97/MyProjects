package com.proectpackage.PnuematicProductsInformationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PnuematicProductsInformationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
