package com.hospitalservice.HospitalManagementInformationService.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class SanjeevaniCare {
	
	//PATIENT MANAGEMENT
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
     int pid;
	 @Column
     String pname;
	 @Column
     String page;
	 @Column
     String pcity;
	 @Column
     String psymptoms;
	
     public SanjeevaniCare() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SanjeevaniCare(int pid, String pname, String page, String pcity, String psymptoms) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.page = page;
		this.pcity = pcity;
		this.psymptoms = psymptoms;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPcity() {
		return pcity;
	}

	public void setPcity(String pcity) {
		this.pcity = pcity;
	}

	public String getPsymptoms() {
		return psymptoms;
	}

	public void setPsymptoms(String psymptoms) {
		this.psymptoms = psymptoms;
	}

	@Override
	public String toString() {
		return "SanjeevaniCare [pid=" + pid + ", pname=" + pname + ", page=" + page + ", pcity=" + pcity
				+ ", psymptoms=" + psymptoms + "]";
	}
	
	
     
     
     
	
	
	

}
