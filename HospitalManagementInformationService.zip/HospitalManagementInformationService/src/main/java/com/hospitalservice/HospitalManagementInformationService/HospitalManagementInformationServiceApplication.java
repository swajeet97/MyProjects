package com.hospitalservice.HospitalManagementInformationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagementInformationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagementInformationServiceApplication.class, args);
	}

}
