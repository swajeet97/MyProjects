package com.hospitalservice.HospitalManagementInformationService.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalservice.HospitalManagementInformationService.Entity.SanjeevaniCare;
import com.hospitalservice.HospitalManagementInformationService.Repository.DataRepository;

@RestController
public class HospitalAPIService {
	
	@Autowired
	DataRepository dataRepository;
	
	//For fetching list of the patient
	@RequestMapping("/getplist")
	public List<SanjeevaniCare> fetchPatientList(){
		
		List<SanjeevaniCare> cares = dataRepository.findAll(); 
		return cares;
		
	}
	@PostMapping("/addnewpvalue")
	@ResponseStatus(code=HttpStatus.CREATED)
	public void addPatientdata(@RequestBody SanjeevaniCare sanjeevaniCare) {
		dataRepository.save(sanjeevaniCare);
		System.out.println("Patient added Successfully..");
	}
	
	@PutMapping("/modifyinfo/{pid}")
	public SanjeevaniCare updatePatientInfo(@PathVariable int pid) {
		
		SanjeevaniCare patient = dataRepository.findById(pid).get();
		patient.setPcity("Mumbai");
		dataRepository.save(patient);
		return patient;
		
	}
	
	@DeleteMapping("/deletepinfo/{pid}")
	@ResponseStatus(code = HttpStatus.ACCEPTED)
	public void removePatientInfo(@PathVariable int pid) {
		
	SanjeevaniCare patient = dataRepository.findById(pid).get();

		dataRepository.delete(patient);
		
	}
	
	@GetMapping("/fetchpbyid/{pid}")
	public SanjeevaniCare getpatientbyid (@PathVariable int pid) {
		
		SanjeevaniCare patient = dataRepository.findById(pid).get();
		return patient;
		
	}
	
	

}
