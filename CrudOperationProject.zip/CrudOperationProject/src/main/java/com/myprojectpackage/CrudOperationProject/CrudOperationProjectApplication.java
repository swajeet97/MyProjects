package com.myprojectpackage.CrudOperationProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperationProjectApplication.class, args);
	}

}
