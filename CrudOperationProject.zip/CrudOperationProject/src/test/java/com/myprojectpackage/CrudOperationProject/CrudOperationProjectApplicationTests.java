package com.myprojectpackage.CrudOperationProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperationProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
