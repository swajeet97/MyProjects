package com.hospitalpackage.HopsitalReportsData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopsitalReportsDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopsitalReportsDataApplication.class, args);
	}

}
