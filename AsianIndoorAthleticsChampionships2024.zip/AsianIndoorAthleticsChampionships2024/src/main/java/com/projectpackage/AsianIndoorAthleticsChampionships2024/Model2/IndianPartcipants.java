package com.projectpackage.AsianIndoorAthleticsChampionships2024.Model2;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class IndianPartcipants {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int pid;
	@Column
	String pname;
	@Column
	String pcountry;
	@Column
	String page;
	@Column
	String pachievement;
	@Column
	String pevent;
	
	public IndianPartcipants() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IndianPartcipants(int pid, String pname, String pcountry, String page, String pachievement, String pevent) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pcountry = pcountry;
		this.page = page;
		this.pachievement = pachievement;
		this.pevent = pevent;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcountry() {
		return pcountry;
	}

	public void setPcountry(String pcountry) {
		this.pcountry = pcountry;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPachievement() {
		return pachievement;
	}

	public void setPachievement(String pachievement) {
		this.pachievement = pachievement;
	}

	public String getPevent() {
		return pevent;
	}

	public void setPevent(String pevent) {
		this.pevent = pevent;
	}

	@Override
	public String toString() {
		return "IndianPartcipants [pid=" + pid + ", pname=" + pname + ", pcountry=" + pcountry + ", page=" + page
				+ ", pachievement=" + pachievement + ", pevent=" + pevent + "]";
	}
	
	
	
	
	
	

}
