package com.projectpackage.AsianIndoorAthleticsChampionships2024.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.projectpackage.AsianIndoorAthleticsChampionships2024.Model.Country;
import com.projectpackage.AsianIndoorAthleticsChampionships2024.Model2.IndianPartcipants;
import com.projectpackage.AsianIndoorAthleticsChampionships2024.Repository.GamesRepository;

@RestController
public class GamesApiService {
	
	@Autowired
	GamesRepository gamesRepository;
	
	
	@RequestMapping("countriescount")
	int totalcoutriesparticipated(){
		
		return 26;
		
	}
	
	@GetMapping("countriesachievements")
	public List<Country> fetchallthecountries(){
		
		List<Country> countries = gamesRepository.findAll();
		return countries;
		
	}
	
	@PostMapping("newlyaddedinfo")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void addnewcountrydetails(@RequestBody Country country) {
		
		gamesRepository.save(country);
		System.out.println("new country information added successfully..");
	}
	
	
	@PutMapping("updateachievements")
	public Country updateCountryachievements(@PathVariable int countryrank) {
		
		Country country = gamesRepository.findById(countryrank).get();
		country.setTotalmedaltally(6);
		gamesRepository.save(country);
		return country;
	
	}
	
	@DeleteMapping("/deletecountryinfo/{countryrank}")
	public void removecountryinfo(@PathVariable int countryrank) {
		
		Country country =gamesRepository.findById(countryrank).get();
		
		gamesRepository.delete(country);
		
	}
	
	@GetMapping("/displayinfobyid/{countryrank}")
	public Country fetchcountryinfobyrank(@PathVariable int countryrank) {
		
		Country country = gamesRepository.findById(countryrank).get();
		
		
		return country;
		
	}
	
	
	
	

}
