package com.projectpackage.AsianIndoorAthleticsChampionships2024.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.projectpackage.AsianIndoorAthleticsChampionships2024.Model.Country;

@Repository
@Component
public interface GamesRepository extends JpaRepository<Country, Integer>{

}
