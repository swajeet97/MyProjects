package com.projectpackage.AsianIndoorAthleticsChampionships2024.Controller2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.projectpackage.AsianIndoorAthleticsChampionships2024.Model2.IndianPartcipants;
import com.projectpackage.AsianIndoorAthleticsChampionships2024.Repository2.ParticipantsRepository;

@RestController
public class ParticipantsAPISerivece {
	
	@Autowired
	ParticipantsRepository participantsRepository;
	
	
	@RequestMapping("pcountofindia")
	int totalparticipantsfromindia() {
		return 13;
		
	}
	
	@RequestMapping("malecount")
	int maleparticipantsfromindia()  {
		
		return 7;
		
	}
	
	@RequestMapping("femalecount")
	int femaleparticipantsfromindia()  {
		
		return 6;
		
	}
	
	@GetMapping("IndParticipantsList")
	public List<IndianPartcipants> fetchIndianParticipants(){
		
		List<IndianPartcipants> indianPartcipants = participantsRepository.findAll();
		
		return indianPartcipants;
		
	}
	
	@PostMapping("insertparticipant")
	@ResponseStatus(code=HttpStatus.CREATED)
	public void addParticipants(@RequestBody IndianPartcipants partcipants) {
		
		participantsRepository.save(partcipants);
		
		System.out.println("Participant Added Successfully..");
		
	}
	
	@PutMapping("/updatepinfo/{pid}")
	public IndianPartcipants updateparticipant(@PathVariable int pid) {
		
		IndianPartcipants partcipants = participantsRepository.findById(pid).get();
		partcipants.setPachievement("(Finalist) 4th (18.59m)");
		participantsRepository.save(partcipants);
		return partcipants;
		
	}
	
	@PutMapping("/updatepinfo2/{pid}")
	public IndianPartcipants updateparticipant2(@PathVariable int pid) {
		
		IndianPartcipants partcipants = participantsRepository.findById(pid).get();
		partcipants.setPachievement("(Finalist) 5th(6.27m)");
		participantsRepository.save(partcipants);
		return partcipants;
		
	}
	
	@PutMapping("/updatepinfo3/{pid}")
	public IndianPartcipants updateparticipant3(@PathVariable int pid) {
		
		IndianPartcipants partcipants = participantsRepository.findById(pid).get();
		partcipants.setPachievement("(Finalist) 6th(6.23m)");
		participantsRepository.save(partcipants);
		return partcipants;
		
	}
	
	@DeleteMapping("/deletepinfo/{pid}")
	@ResponseStatus(code = HttpStatus.GONE)
	public void removeIndianParticipant (@PathVariable int pid) {
		
		IndianPartcipants partcipants = participantsRepository.findById(pid).get();
		participantsRepository.delete(partcipants);
	}
	
	@GetMapping("/getpbyid/{pid}")
	public IndianPartcipants fetchIndianparticipant (@PathVariable int pid) {
		
		IndianPartcipants partcipants = participantsRepository.findById(pid).get();
		
		return partcipants;
		
	}
}
