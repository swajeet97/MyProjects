package com.projectpackage.AsianIndoorAthleticsChampionships2024.Model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Country {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int countryrank;
	@Column
	String countryname;
	@Column
	int gmedaltally;
	@Column
	int smedaltally;
	@Column
	int bmedaltally;
	@Column
	int totalmedaltally;
	
	
	public Country(int countryrank, String countryname, int gmedaltally, int smedaltally, int bmedaltally,
			int totalmedaltally) {
		super();
		this.countryrank = countryrank;
		this.countryname = countryname;
		this.gmedaltally = gmedaltally;
		this.smedaltally = smedaltally;
		this.bmedaltally = bmedaltally;
		this.totalmedaltally = totalmedaltally;
	}
	public Country() {
		super();
		
	}
	public int getCountryrank() {
		return countryrank;
	}
	public void setCountryrank(int countryrank) {
		this.countryrank = countryrank;
	}
	public String getCountryname() {
		return countryname;
	}
	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}
	public int getGmedaltally() {
		return gmedaltally;
	}
	public void setGmedaltally(int gmedaltally) {
		this.gmedaltally = gmedaltally;
	}
	public int getSmedaltally() {
		return smedaltally;
	}
	public void setSmedaltally(int smedaltally) {
		this.smedaltally = smedaltally;
	}
	public int getBmedaltally() {
		return bmedaltally;
	}
	public void setBmedaltally(int bmedaltally) {
		this.bmedaltally = bmedaltally;
	}
	public int getTotalmedaltally() {
		return totalmedaltally;
	}
	public void setTotalmedaltally(int totalmedaltally) {
		this.totalmedaltally = totalmedaltally;
	}
	@Override
	public String toString() {
		return "Country [countryrank=" + countryrank + ", countryname=" + countryname + ", gmedaltally=" + gmedaltally
				+ ", smedaltally=" + smedaltally + ", bmedaltally=" + bmedaltally + ", totalmedaltally="
				+ totalmedaltally + "]";
	}
    
	
	
	
	

}
