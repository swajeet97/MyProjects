package com.projectpackage.AsianIndoorAthleticsChampionships2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsianIndoorAthleticsChampionships2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
