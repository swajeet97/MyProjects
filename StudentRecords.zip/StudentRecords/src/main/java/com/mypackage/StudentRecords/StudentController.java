package com.mypackage.StudentRecords;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	@Autowired
	StudentService studentService = null;
	
	
	@RequestMapping("studentscount")
	int noofStudentsinCollege(){
		return 1000;
	}
	
	@GetMapping("collegestudents")
	ArrayList<String> nameofStudentsinCollege(){
		
		ArrayList<String> listStudents = new ArrayList<String>();
		
		listStudents.add("Jay");
		listStudents.add("Sameer");
		listStudents.add("Vansh");
		listStudents.add("Kiran");
		listStudents.add("Danish");
		
		return listStudents;
		
		
	}
	
	
	
	@GetMapping("studentsbystream/{streamname}")
	ArrayList<String> getstudentsbyStream(@PathVariable String streamname){
		
		ArrayList<String> listStudents = new ArrayList<String>();
		
		if (streamname.equals("CS")) {
		
		   listStudents.add("Jay");
		   listStudents.add("Sameer");
		   listStudents.add("Danish");
		} else if(streamname.equals("MECH")){
			listStudents.add("Vansh");
			}
		else if(streamname.equals("ENTC")){
			listStudents.add("Kiran");
			
		} else {
		
			listStudents.add(null);
		}	
		
		
		return listStudents;
		
	}
	
	@RequestMapping("newstudentinfo")
	Student getStudentinfo() {
		
		Student student = new Student(6, "Sharib", "5thSept 2000", "ENTC", "3rd year");
		return student;
		
	}
	
	@PostMapping("enrolledstudent")
	public void enrollnewStudent(@RequestBody Student student) {
		System.out.println("Enrolled Student >> " +student);
	}
	
	@RequestMapping("enrolledstudents")//move to service class using spring ioc
	ArrayList<Student> enrollnewStudents() throws Exception{
		ArrayList<Student> listenrolledStudents = StudentService.enrollnewStudents();
			
		return listenrolledStudents;
	}
	
}
	


	