package com.mypackage.StudentRecords;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component
public class StudentDao {
	
	public static ArrayList<Student> enrollnewStudents() throws Exception{
		Class.forName("com.mysql,jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentrecorddb1","root", "Swajit@1997");
		String sql = "select * from student";
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery(sql);
		ArrayList<Student> listenrolledStudents = new ArrayList<Student>();
		while (resultSet.next()) {
			int stuid = resultSet.getInt(1);
			String stuname = resultSet.getString(2);
			String studob = resultSet.getString(3);
			String stustream =resultSet.getString(4);
			String stuacyear =resultSet.getString(5);
		    Student student = new Student(stuid, stuname, studob, stustream, stuacyear);
		    listenrolledStudents.add(student);
		}
		return listenrolledStudents;
		
	}


}
