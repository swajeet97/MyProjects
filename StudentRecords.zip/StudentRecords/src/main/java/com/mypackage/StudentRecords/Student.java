package com.mypackage.StudentRecords;

public class Student {
	
	int stuid;
	String stuname;
	String studob;
	String stustream;
	String stuacyear;
	public Student(int stuid, String stuname, String studob, String stustream, String stuacyear) {
		super();
		this.stuid = stuid;
		this.stuname = stuname;
		this.studob = studob;
		this.stustream = stustream;
		this.stuacyear = stuacyear;
	}
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getStudob() {
		return studob;
	}
	public void setStudob(String studob) {
		this.studob = studob;
	}
	public String getStustream() {
		return stustream;
	}
	public void setStustream(String stustream) {
		this.stustream = stustream;
	}
	public String getStuacyear() {
		return stuacyear;
	}
	public void setStuacyear(String stuacyear) {
		this.stuacyear = stuacyear;
	}
	@Override
	public String toString() {
		return "Student [stuid=" + stuid + ", stuname=" + stuname + ", studob=" + studob + ", stustream=" + stustream
				+ ", stuacyear=" + stuacyear + "]";
	}
	
	

}
