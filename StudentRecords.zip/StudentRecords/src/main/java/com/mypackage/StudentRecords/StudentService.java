package com.mypackage.StudentRecords;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	
	public static ArrayList<Student> enrollnewStudents() throws Exception{
		ArrayList<Student> listenrolledStudents = StudentDao.enrollnewStudents();
		return listenrolledStudents;
		
		
		
	}
	

}
