package com.mypackage.StudentRecords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRecordsApplicationTests {

	@Test
	void contextLoads() {
	}

}
