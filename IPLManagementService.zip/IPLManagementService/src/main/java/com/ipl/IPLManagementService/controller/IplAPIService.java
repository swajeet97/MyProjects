package com.ipl.IPLManagementService.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.IPLManagementService.Model.IplTeam;
import com.ipl.IPLManagementService.Repository.IplRepository;
@RestController
public class IplAPIService {
	
	@Autowired
	IplRepository repository;
	
	
	@RequestMapping("/getallteams")
	public List<IplTeam> fetchalltheTeamsdetails() {
		List<IplTeam> teams = repository.findAll();
		return teams;
		
	}
	
	@PostMapping("/newteaminfo")
	public void addTeamDetails (@RequestBody IplTeam iplTeam) {
		
		repository.save(iplTeam);
		System.out.println("The team is added Successfully..");
		
	}
	
	@PutMapping("/modifyteam/{teamrank}")
	public IplTeam updateteaminfo(@PathVariable int teamrank) {
		IplTeam iplTeam = repository.findById(teamrank).get();
		iplTeam.setOwnername("Manoj Badale");
		iplTeam.setHeadcoachname("Kumar Sangakkara");
		repository.save(iplTeam);
		return iplTeam;
	}
	
	@PutMapping("/modifyteam2/{teamrank}")
	public IplTeam updateteaminfo2(@PathVariable int teamrank) {
		IplTeam iplTeam = repository.findById(teamrank).get();
		iplTeam.setTeamname("Kolkata Knight Riders");
		repository.save(iplTeam);
		return iplTeam;
	}
	
	
	@PutMapping("/modifyteam3/{teamrank}")
	public IplTeam updateteaminfo3(@PathVariable int teamrank) {
		IplTeam iplTeam = repository.findById(teamrank).get();
		iplTeam.setTeamrank(5);
		repository.save(iplTeam);
		return iplTeam;
	}
	@DeleteMapping("deleteteam/{teamrank}")
	public void removetheteaminfo(@PathVariable int teamrank) {
		
		IplTeam iplTeam=repository.findById(teamrank).get();
		repository.delete(iplTeam);
	}
	
	@GetMapping("/fetchteam/{teamrank}")
	public IplTeam gettheteam(@PathVariable int teamrank) {
		IplTeam  iplTeam=repository.findById(teamrank).get();
		return iplTeam;
	
	}
}
