package com.ipl.IPLManagementService.Model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class IplTeam {
	
	@Id
	private int teamrank;
	@Column
	private String teamname;
	@Column
	private String ownername;
	@Column
	private int titlewins;
	@Column
	private String headcoachname;
	@Column
	private String jerseycolor;
	@Column
	private String previousleaguestatus;
	
	public IplTeam() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IplTeam(int teamrank, String teamname, String ownername, int titlewins, String headcoachname,
	   String jerseycolor, String previousleaguestatus) {
		super();
		this.teamrank = teamrank;
		this.teamname = teamname;
		this.ownername = ownername;
		this.titlewins = titlewins;
		this.headcoachname = headcoachname;
		this.jerseycolor = jerseycolor;
		this.previousleaguestatus = previousleaguestatus;
	}
	public int getTeamrank() {
		return teamrank;
	}
	public void setTeamrank(int teamrank) {
		this.teamrank = teamrank;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public String getOwnername() {
		return ownername;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public int getTitlewins() {
		return titlewins;
	}
	public void setTitlewins(int titlewins) {
		this.titlewins = titlewins;
	}
	public String getHeadcoachname() {
		return headcoachname;
	}
	public void setHeadcoachname(String headcoachname) {
		this.headcoachname = headcoachname;
	}
	public String getJerseycolor() {
		return jerseycolor;
	}
	public void setJerseycolor(String jerseycolor) {
		this.jerseycolor = jerseycolor;
	}
	public String getPreviousleaguestatus() {
		return previousleaguestatus;
	}
	public void setPreviousleaguestatus(String previousleaguestatus) {
		this.previousleaguestatus = previousleaguestatus;
	}
	@Override
	public String toString() {
		return "IplTeam [teamrank=" + teamrank + ", teamname=" + teamname + ", ownername=" + ownername + ", titlewins="
				+ titlewins + ", headcoachname=" + headcoachname + ", jerseycolor=" + jerseycolor
				+ ", previousleaguestatus=" + previousleaguestatus + "]";
	}
	
     
}
