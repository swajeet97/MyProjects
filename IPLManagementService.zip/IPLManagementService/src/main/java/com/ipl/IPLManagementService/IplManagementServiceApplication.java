package com.ipl.IPLManagementService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IplManagementServiceApplication.class, args);
	}

}
