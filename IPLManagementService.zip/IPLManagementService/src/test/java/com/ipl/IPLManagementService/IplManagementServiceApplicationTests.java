package com.ipl.IPLManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
