package com.mypackage.EmployeeDemography;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDemographyApplicationTests {

	@Test
	void contextLoads() {
	}

}
