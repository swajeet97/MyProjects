package com.mypackage.EmployeeDemography;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDemographyApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDemographyApplication.class, args);
	}

}
